def test_data_join(spark_session):
    assert spark_session is not None

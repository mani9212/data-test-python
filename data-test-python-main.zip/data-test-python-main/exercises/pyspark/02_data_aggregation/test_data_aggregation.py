def test_data_aggregation(spark_session):
    assert spark_session is not None

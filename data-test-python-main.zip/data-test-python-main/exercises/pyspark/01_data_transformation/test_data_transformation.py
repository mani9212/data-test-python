def test_data_transformation(spark_session):
    assert spark_session is not None
